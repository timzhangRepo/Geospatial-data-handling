package LeetJourney;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Spiro {
        public static void main (String args[]) throws IOException {
            File file = new File("src/SpiroCoordinates.txt");
            PrintWriter pw = new PrintWriter("src/SpiroCoordinates.txt");
            file.createNewFile();
            double R = 0.005;
            double r = 0.001;
            double a = 0.004;
            double t = 0;
            double max = 20 * Math.PI;
            double x = 0, y = 0;
            while(t <= max) {
                x =  -118.28547 + (R + r) * Math.cos((r / R) * t) - a * Math.cos((1 + r / R) * t);
                y =  34.021011 + (R + r) * Math.sin((r / R) * t) - a * Math.sin((1 + r / R) * t);
                pw.printf("%.5f,%.5f\n", x, y);
                t += 0.01;
            }
        }
    }

